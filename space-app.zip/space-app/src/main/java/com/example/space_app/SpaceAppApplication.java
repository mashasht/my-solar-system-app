package com.example.space_app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpaceAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpaceAppApplication.class, args);
	}

}
